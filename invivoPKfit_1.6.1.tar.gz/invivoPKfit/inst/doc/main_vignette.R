## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)


## ----setup--------------------------------------------------------------------
devtools::load_all()

## ----mininal-pk, eval=FALSE---------------------------------------------------
#  cvt_df <- subset(cvt, analyte_dtxsid %in% c("DTXSID8031865",
#                                              "DTXSID0020442"))
#  
#  minimal_pk <- pk(data = cvt_df)

## ----joint_preprocesing, eval=FALSE-------------------------------------------
#  joint_pk <- minimal_pk +
#    facet_data(ggplot2::vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = FALSE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = TRUE) +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  joint_pk <- do_preprocess(joint_pk)
#  joint_pk <- do_fit(joint_pk)

## ----eval=FALSE---------------------------------------------------------------
#  pooled_pk <- minimal_pk +
#    facet_data(ggplot2::vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = TRUE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  pooled_pk <- do_fit(pooled_pk)

## ----eval=FALSE---------------------------------------------------------------
#  separate_pk <- minimal_pk +
#    facet_data(ggplot2::vars(Chemical, Species, Reference)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B")) +
#    scale_conc(dose_norm = FALSE, log10_trans = FALSE) +
#    scale_time(new_units = "auto") +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  separate_pk <- do_fit(separate_pk)

## -----------------------------------------------------------------------------
#select data for a single chemical and species
my_data <- subset(cvt,
                  analyte_dtxsid %in% "DTXSID1021116" & species %in% "rat")



## -----------------------------------------------------------------------------
my_pk <- pk(data = my_data) +
  facet_data(facets = ggplot2::vars(Chemical, Species)) +
  settings_preprocess(suppress.messages = FALSE,
                      keep_data_original = TRUE)

## -----------------------------------------------------------------------------
#preprocess data
my_pk <- do_preprocess(my_pk)

## -----------------------------------------------------------------------------
#get summary data info
my_pk <- do_data_info(my_pk)

## -----------------------------------------------------------------------------
#pre-fitting (get model parameter bounds & starting values)
my_pk <- do_prefit(my_pk)

## -----------------------------------------------------------------------------
#model fitting
my_pk <- do_fit(my_pk)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(data = my_data) +
#    settings_preprocess(suppress.messages = FALSE,
#                        keep_data_original = TRUE)
#  
#  my_pk <- do_fit(my_pk)

## -----------------------------------------------------------------------------
coef(my_pk)

## -----------------------------------------------------------------------------
my_resids <- residuals(my_pk)
head(my_resids)

## -----------------------------------------------------------------------------
my_preds <- predict(my_pk)
head(my_preds)

## -----------------------------------------------------------------------------
predict(my_pk, newdata = data.frame(
  Chemical = "DTXSID1021116",
  Species = "rat",
  Time = seq(0, 5, by = 0.5),
  Time.Units = "hours",
  Dose = 1,
  Route = "iv",
  Media = "plasma",
  exclude = FALSE))

## -----------------------------------------------------------------------------
p <- plot(x = my_pk)
print(p$final_plot)

## -----------------------------------------------------------------------------
p2 <- plot(my_pk,
     use_scale_conc = TRUE
     )
print(p2$final_plot)

## -----------------------------------------------------------------------------
logLik(my_pk)

## -----------------------------------------------------------------------------
AIC(my_pk)

## -----------------------------------------------------------------------------
BIC(my_pk)

## -----------------------------------------------------------------------------
rmse(my_pk)

## -----------------------------------------------------------------------------
rsq(my_pk)

## -----------------------------------------------------------------------------
data_proc <- get_data(my_pk)
head(data_proc)

## -----------------------------------------------------------------------------
get_data_info(my_pk)
get_nca(my_pk)

## -----------------------------------------------------------------------------
my_tkstats <- get_tkstats(my_pk)
head(my_tkstats)

## -----------------------------------------------------------------------------
my_pk <- pk(data = my_data)

## -----------------------------------------------------------------------------
names(my_pk)

## -----------------------------------------------------------------------------
head(my_pk$data_original)

## ----eval = FALSE-------------------------------------------------------------
#  ggplot(data = my_data,
#         aes(x = time_hr,
#             y = conc,
#             color = dose_level_normalized_corrected,
#             shape = as.factor(document_id)
#         )
#  )

## ----eval = FALSE-------------------------------------------------------------
#  pk(data = my_data,
#     mapping = ggplot2::aes(
#                   Chemical = analyte_dtxsid,
#                   Chemical_Name = analyte_name_original,
#                   DTXSID = analyte_dtxsid,
#                   CASRN = analyte_casrn,
#                   Species = species,
#                   Reference = document_id,
#                   Media = conc_medium_normalized,
#                   Route = administration_route_normalized,
#                   Dose = dose_level_normalized,
#                   Dose.Units = "mg/kg",
#                   Subject_ID = subject_id,
#                   Series_ID = series_id,
#                   Study_ID = study_id,
#                   ConcTime_ID = conc_time_id,
#                   N_Subjects = n_subjects_in_series,
#                   Weight = weight_kg,
#                   Weight.Units = "kg",
#                   Time = time_hr,
#                   Time.Units = "hours",
#                   Value = conc,
#                   Value.Units = "mg/L",
#                   Value_SD = conc_sd_normalized,
#                   LOQ = loq
#                 ))

## -----------------------------------------------------------------------------
names(cvt)

## ----eval = FALSE-------------------------------------------------------------
#  Reference = as.character(
#    ifelse(
#      is.na(
#        documents_reference.id
#      ),
#      documents_extraction.id,
#      documents_reference.id
#    )
#  )
#  

## ----eval=FALSE---------------------------------------------------------------
#  Value.Units = "mg/L"

## -----------------------------------------------------------------------------
get_status(my_pk)

## ----eval = FALSE-------------------------------------------------------------
#  
#  my_pk <- pk(my_data)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(my_data) + settings_preprocess()

## -----------------------------------------------------------------------------
formals(settings_preprocess)

## -----------------------------------------------------------------------------
my_pk <- pk(my_data) +
  settings_preprocess() +
  settings_data_info()

## -----------------------------------------------------------------------------
formals(settings_data_info)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(my_data) +
#    settings_preprocess() +
#    settings_data_info() +
#    settings_optimx()

## -----------------------------------------------------------------------------
formals(settings_optimx)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(my_data) +
#    settings_preprocess() +
#    settings_data_info() +
#    settings_optimx() +
#    scale_conc()

## -----------------------------------------------------------------------------
formals(scale_conc)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(my_data) +
#    settings_preprocess() +
#    settings_data_info() +
#    settings_optimx() +
#    scale_conc() +
#    scale_time()

## -----------------------------------------------------------------------------
formals(scale_time)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(my_data) +
#    settings_preprocess() +
#    settings_data_info() +
#    settings_optimx() +
#    scale_conc() +
#    scale_time() +
#    stat_model()

## -----------------------------------------------------------------------------
formals(stat_model)

## -----------------------------------------------------------------------------
`model_1comp`

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <-pk(my_data) +
#    settings_preprocess() +
#    settings_data_info() +
#    settings_optimx() +
#    scale_conc() +
#    scale_time() +
#    stat_model() +
#    stat_error_model()

## -----------------------------------------------------------------------------
formals(stat_error_model)

## ----eval = FALSE-------------------------------------------------------------
#  my_pk <- pk(data = my_data)
#  my_pk <- do_fit(my_pk)

## -----------------------------------------------------------------------------
my_pk <- pk(my_data) +
    #instructions to use an error model that puts all observations in the same group
  stat_error_model(error_group = ggplot2::vars(Chemical, Species)) +
  #instructions for concentration scaling/transformation
  scale_conc(dose_norm = TRUE,
             log10_trans = TRUE) +
  #instructions for time rescaling
  scale_time(new_units = "auto") +
  #instructions to use only one method for optimx::optimx()
  settings_optimx(method = "L-BFGS-B") +
  #instructions to impute missing LOQs slightly differently
  settings_preprocess(calc_loq_factor = 0.5) 

## -----------------------------------------------------------------------------
get_data_original(my_pk)

## -----------------------------------------------------------------------------
get_mapping(my_pk)

## -----------------------------------------------------------------------------
get_status(my_pk)

## -----------------------------------------------------------------------------
get_settings_preprocess(my_pk)

## -----------------------------------------------------------------------------
get_settings_data_info(my_pk)

## -----------------------------------------------------------------------------
get_settings_optimx(my_pk)

## -----------------------------------------------------------------------------
get_scale_conc(my_pk)

## -----------------------------------------------------------------------------
get_scale_time(my_pk)

## -----------------------------------------------------------------------------
get_stat_model(my_pk)

## -----------------------------------------------------------------------------
get_stat_error_model(my_pk)

## -----------------------------------------------------------------------------
my_pk <- my_pk +
  scale_conc(dose_norm = TRUE, log10_trans = FALSE)

## -----------------------------------------------------------------------------
get_scale_conc(my_pk)

## -----------------------------------------------------------------------------
my_pk <- my_pk + stat_model(model = "model_1comp")

## -----------------------------------------------------------------------------
get_stat_model(my_pk)

## -----------------------------------------------------------------------------
my_pk <- do_preprocess(my_pk)

## -----------------------------------------------------------------------------
names(my_pk)

## -----------------------------------------------------------------------------
get_data(my_pk)

## -----------------------------------------------------------------------------
my_pk <- do_data_info(my_pk)

## -----------------------------------------------------------------------------
names(my_pk)

## -----------------------------------------------------------------------------
get_data_info(my_pk)

## -----------------------------------------------------------------------------
get_nca(my_pk)

## -----------------------------------------------------------------------------
my_pk <- do_prefit(my_pk)

## -----------------------------------------------------------------------------
names(my_pk)

## -----------------------------------------------------------------------------
names(my_pk$stat_error_model)

## -----------------------------------------------------------------------------
names(my_pk$stat_model)

## -----------------------------------------------------------------------------
my_pk <- pk(data = my_data) + #initialize a `pk` object
  stat_model(model = c("model_flat",
                       "model_1comp",
                       "model_2comp")) + #add PK models to fit
  settings_optimx(method = "L-BFGS-B") #use only this optimx::optimx() algorithm

get_status(my_pk) #status is 1

## -----------------------------------------------------------------------------
my_pk <- do_fit(my_pk)
get_status(my_pk)

## -----------------------------------------------------------------------------
coef(my_pk) 
get_tkstats(my_pk)

## -----------------------------------------------------------------------------
my_pk <- my_pk + scale_conc(dose_norm = TRUE)

## -----------------------------------------------------------------------------
get_status(my_pk)

## ----error = TRUE-------------------------------------------------------------
coef(my_pk) #throws an error
get_tkstats(my_pk) #throws an error

## -----------------------------------------------------------------------------
my_pk <- do_preprocess(my_pk)
my_pk <- do_fit(my_pk)
get_status(my_pk)

coef(my_pk) 
get_tkstats(my_pk)

