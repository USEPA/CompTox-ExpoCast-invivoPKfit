## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
set.seed(2023)
library(tidyverse, quietly = TRUE)
devtools::load_all() 
library(cowplot)
library(RColorBrewer)
# saveRDS(my_pk_100j, "data-raw/all_cvt_pk_JOINT.rds") 
# my_pk <- readRDS("data-raw/all_cvt_pk_JOINT.rds")


## ----pk_obj_fromSQL, eval=FALSE-----------------------------------------------
#  
#  ### Minimal PK Object ###----
#  # Minimum pk object, add options later
#  # Note that these mappings are now a default mappings, just being verbose here.
#  minimal_pk <- pk(data = cvt,
#                   mapping = ggplot2::aes(
#                     Chemical = analyte_dtxsid,
#                     Chemical_Name = analyte_name_original,
#                     DTXSID = analyte_dtxsid,
#                     CASRN = analyte_casrn,
#                     Species = species,
#                     Reference = document_id,
#                     Media = conc_medium_normalized,
#                     Route = administration_route_normalized,
#                     Dose = dose_level_normalized,
#                     Dose.Units = "mg/kg",
#                     Subject_ID = subject_id,
#                     Series_ID = series_id,
#                     Study_ID = study_id,
#                     ConcTime_ID = conc_time_id,
#                     N_Subjects = n_subjects_in_series,
#                     Weight = weight_kg,
#                     Weight.Units = "kg",
#                     Time = time_hr,
#                     Time.Units = "hours",
#                     Value = conc,
#                     Value.Units = "mg/L",
#                     Value_SD = conc_sd_normalized,
#                     LOQ = loq
#                   ))

## ----pooled_fitting_choices, eval=FALSE---------------------------------------
#  # Types of Choices:
#  ## Dose Normalized
#  ## Log10 transform
#  ## Scale time
#  
#  # Pooled
#  my_pk_000p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = FALSE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_100p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_110p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = TRUE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_111p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = TRUE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_010p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = TRUE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_011p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = TRUE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_001p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = FALSE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  
#  my_pk_101p <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  

## ----joint_fitting_choices, eval=FALSE----------------------------------------
#  # Joint
#  my_pk_000j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = FALSE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_100j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_110j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = TRUE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_111j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = TRUE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_010j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = TRUE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_011j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = TRUE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_001j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = FALSE, log10_trans = FALSE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk_101j <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = FALSE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))

## ----Evaluation-helpers, eval=FALSE-------------------------------------------
#  # Evaluation
#  # Current:
#  
#  get_choices <- function(obj, PJ = "Pooled") {
#    dose_norm <- obj$scales$conc$dose_norm
#    log10_norm <- obj$scales$conc$log10_trans
#    time_scale <- ifelse(obj$scales$time$new_units == "identity", FALSE, TRUE)
#  
#    my_choices <- paste0(dose_norm+0,
#                         log10_norm+0,
#                         time_scale+0,
#                         " ", PJ)
#    return(my_choices)
#  }
#  
#  # Write into package
#  evaluate_choices <- function(obj, PJ = "Pooled") {
#    pk_name <- get_choices(obj, PJ = PJ)
#  
#    cli::cli_progress_step("Winning Model...")
#    # Wide winning model
#    suppressMessages({
#      winning_model <- get_winning_model(obj = obj)
#      wide_winning_model <- winning_model %>%
#        group_by(method, model) %>%
#        count() %>%
#        pivot_wider(names_from = model, values_from = n) %>%
#        mutate(Options = pk_name)
#    })
#  
#  
#    cli::cli_progress_step("Cmax and AUC_inf RMSEs...")
#    # Cmax and AUC_inf RMSEs
#    suppressMessages({
#      RMSE_eval <- eval_tkstats(obj = obj) %>%
#        mutate(Options = pk_name) %>%
#        dplyr::select(Options,
#                      Chemical, Species,
#                      Route, Media, Reference,
#                      method, model,
#                      starts_with("Cmax"),
#                      starts_with("AUC_")) %>%
#        filter(abs(AUC_infinity.nca / AUC_tlast.nca) < 10,
#               is.finite(AUC_infinity.nca), is.finite(AUC_infinity.tkstats),
#               AUC_infinity.nca > 0, AUC_infinity.tkstats > 0) %>%
#        rowwise() %>%
#        mutate(SE_Cmax = (Cmax.tkstats - Cmax.nca)^2,
#               SE_AUC_inf = (AUC_infinity.tkstats - AUC_infinity.nca)^2) %>%
#        filter(!is.na(SE_Cmax), !is.na(SE_AUC_inf)) %>%
#        group_by(Options, method) %>%
#        summarize(RMSE_Cmax = sqrt(mean(SE_Cmax,
#                                        na.rm = FALSE)) %>% signif(digits = 4),
#                  RMSE_AUC = sqrt(mean(SE_AUC_inf,
#                                       na.rm = FALSE)) %>% signif(digits = 4))
#    })
#  
#  
#    cli::cli_progress_step("More detailed metrics...")
#    # Other metrics (detailed)
#    suppressMessages({
#      r2_df <- rsq(obj, use_scale_conc = FALSE) %>%
#      inner_join(winning_model)
#    myAIC <- AIC(obj) %>%
#      inner_join(winning_model)
#    fold_errors_all <- fold_errors(obj) %>%
#      inner_join(winning_model) %>%
#      dplyr::filter(Detect %in% TRUE) %>%
#      dplyr::group_by(!!!obj$data_group, model, method) %>%
#      dplyr::summarize(avg_FoldErr = mean(Fold_Error, na.rm = TRUE) %>%
#                         signif(digits = 4),
#                       median_FoldErr = median(Fold_Error, na.rm = TRUE) %>%
#                         signif(digits = 4),
#                       within_2fold = sum(Fold_Error >= 0.5 & Fold_Error <= 2)/length(Fold_Error) %>%
#                         signif(digits = 4))
#  
#    myRMSE_all <- rmse(obj,
#                       rmse_group = vars(Route, Media, Dose),
#                       use_scale_conc = FALSE) %>%
#      inner_join(winning_model) %>%
#      dplyr::group_by(!!!obj$data_group, model, method) %>%
#      dplyr::summarize(avg_MSE = mean(RMSE^2, na.rm = TRUE) %>%
#                         signif(digits = 4),
#                       median_MSE = median(RMSE^2, na.rm = TRUE) %>%
#                         signif(digits = 4))
#  
#    my_df <- left_join(fold_errors_all, r2_df) %>%
#      inner_join(myAIC) %>%
#      inner_join(myRMSE_all) %>%
#      mutate(Options = pk_name, .before = Chemical)
#  
#    full_list <- list(wide_winning_model, RMSE_eval, my_df)
#    })
#  
#    return(full_list)
#  }
#  gc()

## ----Evaluating choices, eval=FALSE-------------------------------------------
#  
#  ### Evaluations-----
#  my_pk_000p <- do_fit(my_pk_000p, n_cores = 12)  %>% evaluate_choices() # Done
#  my_pk_100p <- do_fit(my_pk_100p, n_cores = 12) %>% evaluate_choices() # Done
#  my_pk_110p <- do_fit(my_pk_110p, n_cores = 12) %>% evaluate_choices() # Done
#  my_pk_111p <- do_fit(my_pk_111p, n_cores = 12) %>% evaluate_choices() # Done
#  rm(my_pk_000p, my_pk_100p,my_pk_110p,my_pk_111p)
#  gc()
#  my_pk_010p <- do_fit(my_pk_010p, n_cores = 10) %>% evaluate_choices() # Done
#  my_pk_011p <- do_fit(my_pk_011p, n_cores = 10) %>% evaluate_choices() # Done
#  my_pk_001p <- do_fit(my_pk_001p, n_cores = 10) %>% evaluate_choices() # Done
#  my_pk_101p <- do_fit(my_pk_101p, n_cores = 10) %>% evaluate_choices() # Done
#  
#  my_pk_000j <- do_fit(my_pk_000j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_100j <- do_fit(my_pk_100j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_110j <- do_fit(my_pk_110j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_111j <- do_fit(my_pk_111j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  rm(my_pk_000j, my_pk_100j, my_pk_110j, my_pk_111j)
#  gc()
#  my_pk_010j <- do_fit(my_pk_010j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_011j <- do_fit(my_pk_011j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_001j <- do_fit(my_pk_001j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  my_pk_101j <- do_fit(my_pk_101j, n_cores = 10) %>% evaluate_choices(PJ = "Joint") # Done
#  
#  # Run after each evaluation
#  # initialization (only run once)
#  {
#  current_pk <- my_pk_101j # Define current evaluated pk object here
#  winning_model_final <- NULL
#  rmse_summary <- NULL
#  detail_stats <- NULL
#  
#  # Run all at once
#  
#  winning_model_final <- bind_rows(winning_model_final, current_pk[[1]])
#  rmse_summary <- bind_rows(rmse_summary, current_pk[[2]])
#  detail_stats <- bind_rows(detail_stats, current_pk[[3]])
#  rm(current_pk)
#  gc()
#  }
#  
#  # For copy + pasting into Excel workbook
#  winning_model_final %>% clipr::write_clip(col.names = FALSE)
#  clipr::clear_clip()
#  rmse_summary %>% clipr::write_clip(col.names = FALSE)
#  clipr::clear_clip()
#  detail_stats %>% clipr::write_clip(col.names = FALSE)
#  clipr::clear_clip()
#  gc()
#  
#  

## ----load_multirefs, eval=FALSE-----------------------------------------------
#  # Reference Multiples
#  multiRef_ChemSpec <- cvt_df %>%
#    ungroup() %>%
#    distinct(analyte_dtxsid, species, document_id) %>%
#    group_by(analyte_dtxsid, species) %>%
#    count() %>%
#    arrange(desc(n)) %>%
#    filter(n > 1) %>%
#    dplyr::select(!n)
#  multiRef_ChemSpec %>% nrow() # Surprisingly only 13 Chem + Species have multiple references
#  

## ----Plotting_Summary, eval=FALSE---------------------------------------------
#  finalist_options <- c("000 Pooled", "000 Joint",
#                        "100 Pooled", "100 Joint",
#                        "101 Pooled", "101 Joint")
#  
#  # What are the sheets names
#  readxl::excel_sheets(paste(Sys.getenv("OD_DIR"),
#                             "DataSummary_9_21_2023.xlsx",
#                             sep = "/")) # Predictions Evaluation
#  
#  preval <- readxl::read_xlsx(paste(Sys.getenv("OD_DIR"),
#                                    "DataSummary_9_21_2023.xlsx",
#                                    sep = "/"),
#                              sheet = "Predictions Evaluation") %>%
#    left_join(multiRef_ChemSpec,
#              by = join_by(Chemical == analyte_dtxsid,
#                           Species == species)) %>%
#    filter(method %in% "L-BFGS-B",
#           Options %in% finalist_options) %>%
#    distinct()
#  
#  
#  preval %>%
#    separate(Options, sep = " ",
#             into = c("Options", "Error_Model")) %>%
#    ggplot(aes(x = avg_FoldErr,
#               color = Options)) +
#    geom_freqpoly(bins = 10) +
#    facet_grid(cols = vars(Error_Model))
#  
#  preval %>%
#    separate(Options, sep = " ",
#             into = c("Options", "Error_Model")) %>%
#    group_by(Options, Error_Model) %>%
#    summarize(totalFoldError = sum(avg_FoldErr))
#  
#  readxl::read_xlsx(paste(Sys.getenv("OD_DIR"),
#                                    "DataSummary_9_21_2023.xlsx",
#                                    sep = "/"),
#                              sheet = "Fit_Counts") %>%
#    filter(Options %in% finalist_options, method %in% "L-BFGS-B")
#  
#  readxl::read_xlsx(paste(Sys.getenv("OD_DIR"),
#                                    "DataSummary_9_21_2023.xlsx",
#                                    sep = "/"),
#                              sheet = "Cmax and AUC_inf Evaluation") %>%
#    filter(Options %in% finalist_options, method %in% "L-BFGS-B")
#  
#  
#  library(broom)
#  
#  filtered_preval <- preval %>%
#    filter(if_all(where(is.numeric), is.finite))
#  
#  filtered_preval %>%
#    dplyr::select(Chemical, Species, model, method, Options, Rsq) %>%
#    mutate(time_scaled = ifelse(str_detect(Options,
#                                           pattern = "^\\d\\d1"),
#                                "Time_Scaled",
#                                "notTime_Scaled"),
#           Options = str_remove(Options, pattern = "\\d(?=[:blank:])")) %>%
#    # dplyr::select(-Options) %>%
#    pivot_wider(names_from = time_scaled, values_from = Rsq) %>%
#    mutate(differ = Time_Scaled - notTime_Scaled) %>%
#    View()
#  
#  
#  fit <- lm(within_2fold ~ avg_FoldErr, data = filtered_preval)
#  summary(fit)
#  tidy(fit)
#  head(augment(fit))
#  glance(fit)
#  
#  filtered_preval %>% group_by(Options) %>%
#    nest() %>%
#    mutate(fit = map(data, \(x) {
#      lm(within_2fold ~ avg_FoldErr, data = x)
#      }),
#      tidy_fit = map(fit, tidy)) %>%
#    unnest(tidy_fit) %>%
#    dplyr::select(Options, term, estimate, std.error, statistic) %>%
#    View()
#  
#  
#  Cmax_AUC <- readxl::read_xlsx(paste(Sys.getenv("OD_DIR"),
#                                    "DataSummary_8_18_2023.xlsx",
#                                    sep = "/"),
#                              sheet = "Cmax and AUC_inf Evaluation") %>%
#    dplyr::select(1:4) %>%
#    distinct()
#  
#  
#  Cmax_AUC %>%
#    mutate(DFO = rank(sqrt(RMSE_Cmax^2 + signif(RMSE_AUC, 5)^2)),
#           OLS = rank(abs(RMSE_Cmax + signif(RMSE_AUC, 5))/sqrt(2))) %>%
#    #filter(DFO < 11 | OLS < 11) %>%
#    arrange(DFO, OLS) %>%
#    dplyr::select(-RMSE_Cmax, -RMSE_AUC) %>% View()
#    clipr::write_clip()
#  
#  
#  Cmax_AUC %>%
#    mutate(DFO = rank(sqrt(RMSE_Cmax^2 + RMSE_AUC^2)),
#           OLS = rank(abs(RMSE_Cmax + RMSE_AUC)/sqrt(2))) %>%
#    ggplot(aes(
#      x = DFO,
#      y = OLS,
#      fill = Options
#    )) + geom_point(shape = 21)
#  
#  

## ----Final_Options, eval=FALSE------------------------------------------------
#  my_pk <- minimal_pk +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = TRUE,
#                        suppress.messages = FALSE) +
#    settings_optimx(method = c("L-BFGS-B")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    stat_error_model(error_group = vars(Chemical, Species, Reference))
#  
#  my_pk <- do_preprocess(my_pk)
#  cvt_DTXSIDs <- unique(my_pk$data$Chemical)
#  
#  
#  my_pk <- do_data_info(my_pk)
#  
#  my_pk <- do_prefit(my_pk) # needs reframe somewhere
#  
#  
#  {
#    start <- Sys.time()
#    my_pk <- do_fit(my_pk,
#                    n_cores = 12)
#    round(Sys.time() - start, 4)
#  }
#  
#  

## ----data_aggregation, eval=FALSE---------------------------------------------
#  # Need the following data for any of the subsequent plots
#  
#  # after fitting pk object for all cvt objects or reading the fitted pk object in `setup`
#  winmodel <- get_winning_model(my_pk)
#  my_preds <- inner_join(predict(my_pk, use_scale_conc = TRUE), winmodel)
#  my_residuals <- residuals(my_pk, use_scale_conc = FALSE) %>%
#    inner_join(winmodel)
#  my_tkstats <- eval_tkstats(my_pk)
#  my_nca <- get_nca(my_pk)
#  all_my_data <- get_data(my_pk)
#  
#  fe_df <- fold_errors(my_pk, method = "L-BFGS-B") %>% inner_join(winmodel)
#  # May need to change the use_scale_conc defaults
#  r2_df <- rsq(my_pk, method = "L-BFGS-B", use_scale_conc = FALSE) %>%
#    inner_join(winmodel)
#  myAIC <- AIC(my_pk, method = "L-BFGS-B") %>%
#    inner_join(winmodel)
#  myRMSE <- rmse(my_pk, method = "L-BFGS-B",
#                 rmse_group = vars(Route, Media, Dose),
#                 use_scale_conc = FALSE) %>%
#    inner_join(winmodel)
#  
#  # Something wrong with the summary method... maybe only use detects?
#  fold_errors_all <- fe_df %>%
#    dplyr::filter(Detect %in% TRUE) %>%
#    dplyr::group_by(!!!my_pk$data_group, model, method) %>%
#    dplyr::summarize(avg_FoldErr = mean(Fold_Error, na.rm = TRUE),
#                  median_FoldErr = median(Fold_Error, na.rm = TRUE),
#                  within_2fold = sum(Fold_Error >= 0.5 & Fold_Error <= 2)/length(Fold_Error))
#  
#  myRMSE_all <- myRMSE %>%
#    dplyr::group_by(!!!my_pk$data_group, model, method) %>%
#    dplyr::summarize(avg_MSE = mean(RMSE^2, na.rm = TRUE),
#                  median_MSE = median(RMSE^2, na.rm = TRUE))
#  
#  
#  my_coefs <- coef(my_pk) %>% inner_join(winmodel) %>% inner_join(myAIC)
#  
#  my_coefs %>% dplyr::select(-sigma_value, -error_group, -coefs_vector) %>%
#    ungroup() %>%
#    distinct() %>%
#    inner_join(other_coefs %>% dplyr::select(model, method, Chemical, Species)) ->
#    my_coefs
#  
#  
#  

## ----fig4A, eval=FALSE--------------------------------------------------------
#  
#  all_my_data %>%
#    filter(Detect %in% TRUE,
#           exclude %in% FALSE,
#           Dose > 0) %>%
#    group_by(Chemical,
#             Species,
#             Reference,
#             Route,
#             Media,
#             Dose, Time) %>%
#    filter(n() > 1,
#           sum(is.na(Conc)) != n(),
#           Conc > LOQ) %>% nrow()
#    mutate(meanConc = mean(Conc, na.rm = TRUE)) %>%
#    ungroup() %>%
#    rowwise() %>%
#    mutate(foldConc = Conc / meanConc) %>%
#    filter(Route == "iv") %>%
#    count(foldConc < 0.5) %>%
#    {.[[2,2]]/(.[[1,2]] + .[[2,2]])}
#  # Stats for ALL | ORAL | IV
#  # 88.64% inside twofold | 87.20%  | 91.23%
#  # 2.23%  above twofold  | 2.52%   | 1.70%
#  # 9.11%  below twofold  | 10.25%  | 7.04%
#  
#  pl5A <- all_my_data %>%
#    filter(Detect %in% TRUE,
#           exclude %in% FALSE,
#           Dose > 0) %>%
#    group_by(Chemical,
#             Species,
#             Reference,
#             Route,
#             Media,
#             Dose, Time) %>%
#    filter(n() > 1,
#           sum(is.na(Conc)) != n(),
#           LOQ < Conc) %>%
#    mutate(meanConc = mean(Conc, na.rm = TRUE)) %>%
#    ungroup() %>%
#    rowwise() %>%
#    mutate(foldConc = Conc / meanConc) %>%
#    # Plotting
#    ggplot(aes(x = foldConc)) +
#    geom_histogram(binwidth = 0.2,
#                   fill = "grey5",
#                   color = "grey5",
#                   linewidth = 0.4) +
#    coord_cartesian(xlim =  c(0, 4),
#                    ylim = c(0, 4000)) +
#    scale_y_continuous(expand = c(0, 0),
#                       breaks = c(0, 1000, 2000, 3000),
#                       labels = c("0", "1", "2", "3")) +
#    expand_limits(y = 0) +
#    geom_vline(xintercept = c(0.5, 2), color = "red3", linetype = "dashed") +
#    theme_classic() +
#    labs(x = "Mean-normalized\nconcentration",
#                  y = "Observations\n(thousands)") +
#    theme(text = element_text(size = 10),
#          panel.border = element_rect(color = "black", linewidth = 1, fill = NA),
#          panel.background = element_blank(),
#          panel.grid.major.y = element_line(color = "grey90", linewidth = 0.4),
#          axis.title = element_text(face = "bold"),
#          axis.line = element_blank(),
#          plot.background = element_blank(),
#          axis.ticks.y = element_blank())
#  
#  pl5A
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "NormalizedConcentrations_2023-09-29.png"),
#         plot = pl5A,
#         height = 2.2,
#         width = 2.5,
#         units = "in",
#         device = "png",
#         dpi = 300)
#  
#  
#  all_my_data %>%
#    filter(Detect %in% TRUE,
#           exclude %in% FALSE,
#           Dose > 0) %>%
#    group_by(Chemical,
#             Species,
#             Reference,
#             Route,
#             Media,
#             Dose, Time) %>%
#    count() %>%
#    mutate(Replicated = ifelse(n > 1, TRUE, FALSE)) %>%
#    distinct() %>% .$Replicated %>% table()
#    ggplot(aes(fill = Replicated)) +
#    geom_bar(position = "stack",
#             color = "black")
#    labs(x = "", y = "Timepoints") +
#    scale_fill_manual(values = c("black", "white")) +
#    scale_y_continuous(expand = c(0, NA)) +
#    theme_void() +
#    theme(legend.position = "bottom")
#  

## ----fig4A-2-alt, eval=FALSE--------------------------------------------------
#  iad_summary <- cvt %>% filter(conc > 0, n_subjects_in_series == 1) %>%
#    group_by(analyte_dtxsid, species, administration_route_normalized,
#             conc_medium_normalized, dose_level_corrected, document_id,
#             time_hr) %>%
#    filter(n() > 1) %>%
#    summarize(conc_sd_calc = sd(conc),
#              conc_avg_calc = mean(conc),
#              n_subjects_in_series = n())
#  
#  sud_summary <- cvt %>% filter(conc > 0,
#                                n_subjects_in_series > 1,
#                                !is.na(conc_sd_normalized)) %>%
#    mutate(conc_sd_calc = conc_sd_normalized,
#           conc_avg_calc = conc) %>%
#    distinct(analyte_dtxsid, species, administration_route_normalized,
#             conc_medium_normalized, dose_level_corrected, document_id,
#             time_hr, conc_sd_calc, conc_avg_calc, n_subjects_in_series)
#  
#  combined_summary <- bind_rows(sud_summary, iad_summary) %>%
#    rowwise() %>%
#    mutate(twofold_95 = ifelse((conc_avg_calc + (2*conc_sd_calc))/conc_avg_calc < 2,
#                               TRUE, FALSE))
#  
#  # With the mapped column names
#  
#  iad_summary <- all_my_data %>% filter(Conc > 0, N_Subjects == 1, Dose > 0) %>%
#    group_by(Chemical, Species, Route, Media, Dose, Reference, Time) %>%
#    filter(n() > 1) %>%
#    summarize(conc_sd_calc = sd(Conc),
#              conc_avg_calc = mean(Conc),
#              n_subjects_in_series = n())
#  
#  sud_summary <- all_my_data %>% filter(Conc > 0, N_Subjects > 1,
#                                        !is.na(Conc_SD), Dose > 0) %>%
#    mutate(conc_sd_calc = Conc_SD,
#           conc_avg_calc = Conc,
#           n_subjects_in_series = N_Subjects) %>%
#    distinct(Chemical, Species, Route, Media, Dose, Reference, Time,
#             conc_sd_calc, conc_avg_calc, n_subjects_in_series)
#  
#  combined_summary <- bind_rows(sud_summary, iad_summary) %>%
#    rowwise() %>%
#    mutate(twofold_95 = ifelse((conc_avg_calc + (2*conc_sd_calc))/conc_avg_calc < 2,
#                               TRUE, FALSE))
#  
#  table(combined_summary$twofold_95)
#  
#  pl5A <- combined_summary %>% ungroup() %>%
#    count(twofold_95) %>%
#    ggplot(aes(x = twofold_95, fill = twofold_95, y = n)) +
#    geom_col(position = position_stack(),
#             color = "black", linewidth = 1) +
#    coord_cartesian(ylim = c(0, 4000)) +
#    scale_y_continuous(expand = c(0, 0),
#                       breaks = c(0, 1000, 2000, 3000),
#                       labels = c("0", "1", "2", "3")) +
#    scale_fill_manual(values = c("black", "white")) +
#    theme_classic() +
#    labs(x = "95% of observations\nwithin factor of 2",
#                  y = "Observations\n(thousands)") +
#    theme(text = element_text(size = 10),
#          panel.border = element_rect(color = "black", linewidth = 1, fill = NA),
#          panel.background = element_blank(),
#          panel.grid.major.y = element_line(color = "grey90", linewidth = 0.4),
#          axis.title = element_text(face = "bold"),
#          axis.line = element_blank(),
#          plot.background = element_blank(),
#          axis.ticks.y = element_blank(),
#          legend.position = "none")
#  
#  

## ----fig4B-cowplot, eval=FALSE------------------------------------------------
#  
#  pl5B <- all_my_data %>%
#    group_by(Chemical,
#             Species,
#             Reference,
#             Route,
#             Dose, Time) %>%
#    filter(n() > 1,
#           sum(is.na(Conc_trans)) != n(),
#           exclude == FALSE) %>%
#    mutate(meanConc = mean(Conc_trans, na.rm = TRUE)) %>%
#    ungroup() %>%
#    rowwise() %>%
#    mutate(foldConc = Conc_trans / meanConc) %>%
#    inner_join(my_tkstats %>%
#                dplyr::select(Chemical, Species,
#                              Route, Media,
#                              tmax = tmax.nca) %>%
#                filter(!is.na(tmax))) %>%
#    group_by(Chemical,
#             Species,
#             Reference,
#             Route,
#             Media,
#             Dose) %>%
#    mutate(
#           normTime = ifelse(
#             Route == "iv",
#             1 + Time/max(Time),
#             ifelse(
#               Time > tmax,
#               ((Time - tmax)/max(Time)) + 1,
#               0.5 + Time/(2*tmax)
#             )
#           )) %>%
#    ggplot(aes(
#      x = normTime,
#      y = foldConc
#    )) +
#    geom_point(alpha = 0.1, size = 0.7) +
#    geom_vline(xintercept = 1, color = "blue",
#               linewidth = 0.8, linetype = "dashed") +
#    geom_vline(xintercept = 2, color = "green4",
#               linewidth = 0.8, linetype = "dashed") +
#    geom_hline(yintercept = c(0.5, 2), color = "red3",
#               linewidth = 0.8, linetype = "dashed") +
#    facet_grid(cols = vars(Route),
#               scales = "free_x") +
#    labs(x = "ADME-Normalized Time",
#         y = "Mean-Normalized\nConcentration") +
#    theme(text = element_text(size = 10),
#          panel.border = element_rect(color = "black", fill = NA, size = 1),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          axis.text.x = element_blank(),
#          axis.title = element_text(face = "bold"),
#          panel.spacing = unit(0.125, units = "in"),
#          plot.background = element_blank(),
#          legend.position = "none")
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ADME_NormTime-NormConcs_onlyDetects_2023-09-29.png"),
#         height = 4,
#         width = 5,
#         units = "in",
#         dpi = 300)
#  
#  
#  # Make the Combination Plot----
#  
#  plot_grid(pl5A, pl5B, labels = c("A", "B"),
#                       align = "h", axis = "bt", rel_widths = c(1, 2))
#  
#  
#  figure5 <- plot_grid(pl5A, pl5B, labels = c("A", "B"),
#                       align = "h", axis = "bt", rel_widths = c(1, 1.75))
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "Figure5alt_onlyDetects_2023-10-02.png"),
#         plot = figure5,
#         bg = "white",
#         height = 3.25,
#         width = 6.5,
#         units = "in",
#         dpi = 300)
#  

## ----cvt_analysis, eval=FALSE-------------------------------------------------
#  data_range <- all_my_data %>%
#    filter(Detect) %>%
#    group_by(Chemical, Species, Reference, Media, Route, Dose, Dose.Units) %>%
#    summarize(maxT = max(Time)/24,
#           concRange = log10(max(Conc)/min(Conc))) %>%
#    ungroup()
#  
#  
#  sf_2B <- data_range %>%
#    ggplot(aes(x = maxT)) +
#    geom_histogram(fill = "grey5",
#                   bins = 40,
#                   color = "grey5") +
#    scale_x_log10(labels = scales::number,
#                  breaks = c(0.1, 1, 7, 30, 365)) +
#    scale_y_continuous(expand = c(0, 0),
#                       limits = c(0, 60),
#                       breaks = c(0, 10, 20, 30, 40, 50)) +
#    labs(x = "Day of final Timepoint",
#         y = "Count") +
#    theme(aspect.ratio = 1,
#          text = element_text(size = 10),
#          panel.border = element_rect(color = "black", fill = NA, size = 1),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          axis.ticks = element_blank(),
#          axis.line = element_blank())
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "SFig2B_TimePoints_2023-10-02.png"),
#         height = 4,
#         width = 4,
#         units = "in",
#         dpi = 300)
#  
#  
#  sf_2A <- data_range %>%
#    ggplot(aes(x = concRange)) +
#    geom_histogram(fill = "grey5",
#                   bins = 40,
#                   color = "grey5") +
#    scale_y_continuous(expand = c(0, 0),
#                       limits = c(0, 25),
#                       breaks = c(0, 5, 10, 15, 20)) +
#    labs(x = "log10(Concentration Range)",
#         y = "Count") +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA, size = 1),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          axis.text = element_text(size = 10),
#          axis.title = element_text(size = 11))
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "SFig2A_ConcRange_2023-09-29.png"),
#         height = 4,
#         width = 4,
#         units = "in",
#         dpi = 300)
#  
#  
#  plot_grid(sf_2A, sf_2B, labels = "AUTO", align = "h", axis = "bt")
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "SFig2_ConcTimeRanges_2023-10-02.png"),
#         height = 3.25,
#         width = 6,
#         units = "in",
#         dpi = 300)
#  

## ----sFig2-model_performance, eval=FALSE--------------------------------------
#  my_preds %>%
#    right_join(winmodel) %>%
#    rowwise() %>%
#    mutate(Pred_Obs = Conc_trans/Conc_est) %>%
#    filter(is.finite(Pred_Obs),
#           model %in% c("model_1comp", "model_2comp")) %>%
#    # mutate(pass = ifelse(Pred_Obs < 0.5, TRUE, FALSE)) %>%
#    # pull(pass) %>% table()
#    ggplot(aes(x = Pred_Obs)) +
#    geom_histogram(binwidth = 0.5,
#                   fill = "grey5") +
#    scale_x_log10(limits = c(NA, 1E6)) +
#    expand_limits(y = 0) +
#    geom_vline(xintercept = c(0.5, 2), color = "red3", linetype = "dashed") +
#    facet_grid(cols = vars(model),
#               rows = vars(Route)) +
#    labs(x = "Dose-normalized\nPredicted/Observed",
#         y = "Number of Observations") +
#    theme_classic() +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.4))
#  
#  # 91.1% of Pred_Obs are finite
#  # 16.6% Are below two-fold
#  # 33.2%  Are above two-fold
#  # 50.2% Are within twofold
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "PredictedObserved_compartmentModels_2023-11-30.png"),
#         height = 6, width = 6)
#  
#  

## ----fig5-modelPerform-v-dataVar, eval=FALSE----------------------------------
#  
#  
#  pl_7A <- my_preds %>%
#    group_by(Chemical,
#             Species,
#             Route, Media,
#             Dose, Time) %>%
#    filter(n() > 1,
#           sum(is.na(Conc_trans)) != n(),
#           # model %in% c("model_flat"),
#           exclude %in% FALSE,
#           Detect %in% TRUE) %>%
#    mutate(meanConc = mean(Conc_trans, na.rm = TRUE)) %>%
#    ungroup() %>%
#    rowwise() %>%
#    mutate(foldConc = Conc_trans / meanConc,
#           foldPred = Conc_est / Conc_trans) %>%
#    # For percentages
#    # ungroup() %>%
#    # filter(model %in% c("model_flat")) %>%
#    # count((foldPred >= 0.5 & foldPred <= 2) & !(foldConc >= 0.5 & foldConc <= 2)) %>%
#    # {100*.[[2,2]]/(.[[1,2]] + .[[2,2]])}
#    # For Plotting
#    ggplot(aes(
#      y = foldPred,
#      x = foldConc
#    )) +
#    geom_bin2d(bins = 40, color = NA) +
#    geom_hline(yintercept = c(0.5, 2), linetype = "dashed") +
#    geom_vline(xintercept = c(0.5, 2), linetype = "dashed") +
#    facet_grid(cols = vars(model)) +
#    scale_x_log10(labels = scales::label_math(format = log10),
#                  limits = c(0.001, 100)) +
#    scale_y_log10(labels = scales::label_math(format = log10),
#                  limits = c(0.001, 1000)) +
#    scale_fill_viridis_c(option = "cividis",
#                         limits = c(1, 100),
#                         oob = scales::oob_squish) +
#    labs(y = "Model Error",
#         x = "Data Variability") +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA, size = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank())
#  
#  pl_7A
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ModelPerformance_vDataVariability_2023-10-19.png"),
#         height = 3,
#         width = 6.5,
#         device = "png",
#         dpi = 300,
#         units = "in")
#  
#  my_table <- data.frame(
#    c("Both within a factor of 2",
#      "Model too variable",
#      "Data too variable",
#      "Both outside a factor of 2"),
#    c(46.3, 39.5, 2.3, 12),
#    c(46, 44, 1.8, 7.4),
#    c(26, 60, 5, 8.5),
#    c(45, 42.7, 2.3, 10))
#  
#  names(my_table) <- c(" ","1-compartment (%)", "2-compartment (%)", "Flat (%)", "Overall (%)")
#  
#  library(flextable)
#  library(officer)
#  
#  flextable(my_table) %>%
#    border_inner() %>%
#    fontsize(part = "all", size = 11) %>%
#    bold(part = "all", j = 5)
#  
#  table_plot <- gen_grob(flextable(my_table) %>%
#                           border_inner() %>%
#                           fontsize(part = "all", size = 10) %>%
#                           bold(part = "all", j = 5) %>%
#                           autofit())
#  
#  
#  dual_plot <- plot_grid(pl_7A, table_plot, ncol = 1, align = "v",
#            rel_heights = c(1, 0.5))
#  
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ModelPerformance_vDataVariability_wTable_2023-10-02.png"),
#         plot = dual_plot,
#         height = 4.5,
#         width = 6.5,
#         device = "png",
#         bg = "white",
#         dpi = 300,
#         units = "in")

## ----fig5Alt, eval=FALSE------------------------------------------------------
#  # Redo combined summary
#  combined_summary <- bind_rows(sud_summary, iad_summary) %>%
#    rowwise() %>%
#    mutate(twofold_95 = ifelse((conc_avg_calc + (2*conc_sd_calc))/conc_avg_calc < 2,
#                               TRUE, FALSE))
#  
#  # Now
#  this_preds <- inner_join(predict(my_pk), winmodel) %>%
#    rowwise() %>% mutate(foldPred = Conc_est/Conc) %>%
#    distinct(model, method, Chemical, Species, Route, Media, Dose, Time, foldPred) %>%
#    group_by(model, method, Chemical, Species, Route, Media, Dose, Time) %>%
#    summarize(avgFE = mean(foldPred, na.rm = TRUE))
#  
#  pl_7Alt <- this_preds %>%
#    inner_join(combined_summary, by = join_by(Chemical, Species,
#                                              Route, Media,
#                                              Dose, Time)) %>%
#    filter(!is.na(model), avgFE > 0) %>%
#    #
#    # For Plotting
#    ggplot(aes(
#      y = avgFE,
#      x = twofold_95
#    )) +
#    geom_bin2d(bins = 40, color = NA) +
#    geom_hline(yintercept = c(0.5, 2), linetype = "dashed", linewidth = 1, color = "red3") +
#    scale_y_log10(labels = scales::label_math(format = log10),
#                  limits = c(0.0001, 10000)) +
#    scale_fill_viridis_c(option = "cividis",
#                         limits = c(1, 200),
#                         oob = scales::oob_squish) +
#    labs(y = "Model Error",
#         x = "95% of data within 2-fold") +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA, size = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank())
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ModelPerformance_vDataVariability_2023-11-14.png"),
#         height = 4.5,
#         width = 4.5,
#         device = "png",
#         bg = "white",
#         dpi = 300,
#         units = "in")
#  
#  this_preds %>%
#    inner_join(combined_summary, by = join_by(Chemical, Species,
#                                              Route, Media,
#                                              Dose, Time)) %>%
#    filter(!is.na(model), avgFE > 0) %>% ungroup() %>%
#    filter(model == "model_2comp") %>%
#    count(!(avgFE >= 0.5 & avgFE <= 2) & !twofold_95) %>%
#    {100*.[[2,2]]/(.[[1,2]] + .[[2,2]])} %>% round(digits = 1)
#  
#  # Table
#  
#  my_table <- data.frame(
#    c("Reasonable model error and observed variability",
#      "Data variability high, model error reasonable",
#      "Model error high, data variation reasonable",
#      "Both model error and data variability are high"),
#    c(37.2, 6.5,  41.4, 14.8),
#    c(53.6, 3.5,  32.4, 10.4),
#    c(11.0, 16.4, 46.6, 26.0),
#    c(44.2, 5.4,  37.4, 13.0))
#  
#  names(my_table) <- c(" ","1-compartment (%)", "2-compartment (%)", "Flat (%)", "Overall (%)")
#  
#  library(flextable)
#  library(officer)
#  
#  flextable(my_table) %>%
#    border_inner() %>%
#    fontsize(part = "all", size = 11) %>%
#    bold(part = "all", j = 5)
#  
#  table_plot <- gen_grob(flextable(my_table) %>%
#                           border_inner() %>%
#                           fontsize(part = "all", size = 10) %>%
#                           bold(part = "all", j = 5) %>%
#                           autofit())
#  
#  
#  dual_plot <- plot_grid(pl_7Alt, table_plot, ncol = 1, align = "v",
#            rel_heights = c(1, 0.5))
#  
#  dual_plot
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ModelPerformance_vDataVariability_wTable_2023-11-30.png"),
#         plot = dual_plot,
#         height = 4.5,
#         width = 6.5,
#         device = "png",
#         bg = "white",
#         dpi = 300,
#         units = "in")
#  

## ----fig6-goodness-of-fit, eval=FALSE-----------------------------------------
#  
#  
#  
#  my_df <- left_join(fold_errors_all, r2_df) %>% inner_join(myAIC) %>% inner_join(myRMSE_all)
#  
#  mypl <- ggplot(data = my_df,
#                 aes(
#                   x = within_2fold,
#                   y = Rsq,
#                   color = model
#                 )) +
#    geom_point() +
#    geom_abline(slope = 1, color = "red4", linetype = "longdash") +
#    scale_color_manual(values = c("#0398FC", "#D68E09", "black")) +
#    labs(x = "% Fold Error within 2-fold",
#         y = "R-squared value") +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA, size = 1),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          legend.position = "none",
#          legend.title = element_blank(),
#          legend.key = element_blank())
#  panelA_plot <- ggExtra::ggMarginal(mypl, groupFill = TRUE,
#                      type = "histogram",
#                      xparams = list(binwidth = 0.05),
#                      yparams = list(binwidth = 0.05))
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "R2_within2fold_comparison.png"),
#         plot = ggExtra::ggMarginal(mypl, groupFill = TRUE,
#                      type = "histogram",
#                      xparams = list(binwidth = 0.05),
#                      yparams = list(binwidth = 0.05)),
#         height = 5,
#         width = 5,
#         units = "in")
#  
#  panelB_plot <- ggplot(data = myRMSE %>%
#           mutate(RMSE = ifelse(RMSE == 0, NA, RMSE)),
#                 aes(
#                   x = log10(RMSE),
#                   color = model,
#                   fill = model
#                 )) +
#    geom_histogram(bins = 100) +
#    labs(y = "Count") +
#    scale_color_manual(values = c("#0398FC", "#D68E09", "grey10")) +
#    scale_fill_manual(values = c("#0398FC", "#D68E09", "grey10")) +
#    scale_y_continuous(breaks = scales::pretty_breaks(n = 4),
#                       expand = c(0,NA)) +
#    facet_grid(rows = vars(model),
#               cols = vars(Route)) +
#    theme(text = element_text(size = 10),
#          aspect.ratio = 0.6,
#      panel.border = element_rect(color = "black", fill = NA, size = 1),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          strip.background = element_blank(),
#      panel.spacing.y = unit(0.125, units = "in"),
#          legend.position = "bottom",
#          legend.title = element_blank())
#  
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "RMSEs_winningmodel_LBFGSB_zero1E-6_RouteFacet_notNormalized.png"),
#         height = 4,
#         width = 6,
#         units = "in")
#  
#  legend <- get_legend(panelB_plot)
#  
#  plot_grid(plot_grid(panelA_plot,
#                     panelB_plot + theme(legend.position = "none"), labels = c("A", "B"),
#                     axis = "tb", align = "h", rel_heights = c(1,1)), legend,
#            ncol = 1,
#            rel_heights = c(1, 0.1))
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "CombinedPlot_Rsquared_RMSE.png"),
#         height = 4,
#         width = 6.5,
#         bg = "white",
#         units = "in")

## ----sFig3-sigmaDistribution, eval=FALSE--------------------------------------
#  
#  
#  my_coefs <- inner_join(get_winning_model(my_pk), coef(my_pk))
#  my_coefs %>% inner_join(get_data_summary(my_pk)) -> my_coefs
#  
#  
#  my_coefs %>%
#    mutate(model =
#             case_when(
#               model == "model_1comp" ~ "1-compartment",
#               model == "model_2comp" ~ "2-compartment",
#               model == "model_flat"  ~ "Null"
#             )) %>%
#    ggplot(aes(x = sigma_value/n_obs)) +
#    geom_histogram(bins = 15,
#                   color = NA, fill = "grey5") +
#    scale_x_log10(labels = scales::label_math(format = log10)) +
#    facet_grid(cols = vars(model)) +
#    labs(x = "Size-normalized Sigma Value",
#         y = "Number of Observations") +
#    theme(panel.border = element_rect(color = "black", fill = NA, size = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          plot.title = element_text(hjust = 0.5),
#          axis.ticks = element_blank(),
#          axis.line = element_blank())
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "NormalizedSigma_Distributions_2023-07.png"),
#         height = 3, width = 5)
#  

## ----Lombardo_Comparison, eval=FALSE------------------------------------------
#  cvt_DTXSIDs <- unique(my_pk$data$Chemical)
#  # First things first, let's load the data from Lombardo et al.
#  lombardo <- readxl::read_xlsx(
#    paste0(Sys.getenv("FIG_DIR"),
#           "Lombardo2018-Supplemental_82966_revised_corrected.xlsx"),
#    skip = 8)
#  
#  
#  l_batch_search <- readxl::read_xlsx(
#    paste0(Sys.getenv("FIG_DIR"),
#           "LombardoBatchSearch_Name.xlsx"),
#    sheet = "Main Data"
#  )
#  
#  
#  l_batch_search <- l_batch_search[c("INPUT", "CASRN","DTXSID")] %>%
#    distinct() %>%
#    right_join(lombardo[c("Name", "CAS #")], by = c("CASRN" = "CAS #", "INPUT" = "Name"))
#  
#  
#  
#  l_noNamesCASRN <- readxl::read_xlsx(
#    paste0(Sys.getenv("FIG_DIR"),
#           "LombardoBatchSearch_CASRNnoName.xlsx"),
#    sheet = "Main Data"
#  ) %>%
#    dplyr::select(CASRN = INPUT, DTXSID)
#  
#  l_curatedDTX <- read_tsv(paste0(Sys.getenv("FIG_DIR"),
#                           "CuratedIDs_lombardo.txt")) %>%
#    rename(INPUT = Name)
#  
#  
#  l_batch_search <- l_batch_search %>%
#    left_join(l_noNamesCASRN, by = "CASRN") %>%
#    mutate(DTXSID = coalesce(DTXSID.x, DTXSID.y)) %>%
#    dplyr::select(-DTXSID.x, -DTXSID.y) %>%
#    left_join(l_curatedDTX, by = "INPUT") %>%
#    mutate(DTXSID = coalesce(DTXSID.x, DTXSID.y)) %>%
#    dplyr::select(-DTXSID.x, -DTXSID.y)
#  # Now all but two of the IDs are unidentified
#  
#  lombardo <- lombardo %>%
#    right_join(l_batch_search, by = c("Name" = "INPUT"))
#  
#  lombard_abbr <- lombardo %>% dplyr::select(DTXSID,
#                                             hVss = `human VDss (L/kg)`,
#                                             hCltot = `human CL (mL/min/kg)`,
#                                             halflife = `terminal  t1/2 (h)` ) %>%
#    filter(DTXSID %in% cvt_DTXSIDs)
#  
#  # 15 chemicals in common with values for both
#  lombardo_comparison <- my_tkstats %>%
#    dplyr::select(DTXSID = Chemical, Species,
#                  model, Vss.tkstats, CLtot.tkstats) %>%
#    distinct() %>%
#    inner_join(lombard_abbr, by = "DTXSID") %>%
#    filter(!is.na(Vss.tkstats)) %>%
#    arrange(halflife)
#  
#  comparable_ids <- lombardo_comparison %>% pull(DTXSID)
#  
#  lombard_abbr <- lombard_abbr %>%
#    mutate(Species = "human", model = "Lombardo et al.") %>%
#    rename(Vss = hVss, CLtot = hCltot) %>%
#    mutate(CLtot = CLtot*60/1000) %>% # Lombardo reports this as mL/min/kg, need L/h/kg
#    filter(DTXSID %in% comparable_ids)
#  
#  lombardo_comparison <- my_tkstats %>%
#    dplyr::select(DTXSID = Chemical, Species,
#                  model, Vss.tkstats, CLtot.tkstats, halflife.tkstats) %>%
#    filter(DTXSID %in% comparable_ids) %>%
#    distinct() %>%
#    rename(Vss = Vss.tkstats, CLtot = CLtot.tkstats, halflife = halflife.tkstats) %>%
#    bind_rows(lombard_abbr) %>%
#    mutate(model = ifelse(str_detect(model, "^model"), "invivoPKfit", model),
#           DTXSID = factor(DTXSID, levels = unique(comparable_ids)))
#  
#  lombardo_comparison %>%
#    pivot_longer(cols = c("Vss", "CLtot", "halflife")) %>%
#    mutate(name = factor(name, levels = c("halflife", "Vss", "CLtot"))) %>%
#    ggplot(mapping = aes(
#      x = value,
#      y = DTXSID
#    )) +
#    geom_point(aes(color = model,
#                   shape = Species),
#               position = position_dodge(0.7),
#               size = 5/.pt, stroke = 2.5/.pt) +
#    facet_grid(cols = vars(name),
#               scales = "free_x") +
#    scale_shape_manual(values = c(21, 22, 24),
#                       breaks = c("human", "dog", "rat")) +
#    scale_color_manual(values = c("black", "#1064c9")) +
#    guides(color = guide_legend(override.aes = list(shape = 21),
#                                nrow = 2,
#                                title.position = "top",
#                                title.hjust = 0.5),
#           shape = guide_legend(nrow = 1,
#                                title.position = "top",
#                                title.hjust = 0.5)) +
#    theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold", size = 12),
#          text = element_text(size = 10),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          axis.text = element_text(face = "bold"),
#          axis.title.y = element_blank(),
#          axis.title.x = element_blank(),
#          legend.position = "bottom",
#          legend.key = element_blank(),
#          legend.title = element_text(face = "bold"),
#          legend.text = element_text())
#  
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "lombardoComparison_Figure8.png"),
#         height = 4,
#         width = 6.5,
#         device = "png", dpi = 300)
#  
#  
#  

## ----otherMeta-analysis, eval=FALSE-------------------------------------------
#  
#  # Histograms
#  lombardo_hist <- data.frame(Chemical = c(lombardo$DTXSID,
#                                my_tkstats$Chemical),
#                              Vss = c(lombardo$`human VDss (L/kg)`,
#                                my_tkstats$Vss.tkstats),
#                              halflife = c(lombardo$`terminal  t1/2 (h)`,
#                                my_tkstats$halflife.tkstats),
#                              Source = c(rep_len("lombardo",
#                                      length.out = nrow(lombardo)),
#                                rep_len("invivoPKfit",
#                                        length.out = nrow(my_tkstats))))
#  
#  
#  sfig4A <- lombardo_hist %>%
#    ggplot(aes(x = log2(Vss), color = Source,
#               group = Source)) +
#    geom_freqpoly(aes(y = after_stat(ndensity)),
#                  linewidth = 2/.pt,
#                  bins = 20) +
#    labs(y = "Scaled Frequency",
#         x = "Vss") +
#    scale_x_continuous(labels = scales::label_math(expr = 2^.x)) +
#    scale_color_manual(values = c("black", "#1064c9")) +
#    guides(color = guide_legend(nrow = 2, linewidth = 1)) +
#    theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold", size = 12),
#          text = element_text(size = 10),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          axis.text = element_text(face = "bold"),
#          legend.position = "bottom",
#          legend.key = element_blank(),
#          legend.title = element_text(face = "bold"),
#          legend.text = element_text())
#  
#  sfig4A
#  other_meta <- read_csv(
#    file = paste0(Sys.getenv("FIG_DIR"), "SupTableInVivoDatandPreds.csv")) %>%
#    dplyr::select(DTXSID, fbioh, fbior) %>%
#    filter(DTXSID %in% my_tkstats$Chemical)
#  
#  
#  sfig4B <- other_meta %>% left_join(my_tkstats, by = c("DTXSID" = "Chemical")) %>%
#    filter(Species %in% c("rat")) %>%
#    filter(!is.na(Fgutabs.tkstats),
#           !is.na(fbior)) %>%
#    distinct(DTXSID, Species,
#             Fgutabs.tkstats, fbior) %>%
#    pivot_longer(cols = c(Fgutabs.tkstats, fbior),
#                 names_to = "Source",
#                 values_to = "Fgutabs") %>%
#      mutate(Source = ifelse(str_detect(Source, "tkstats"), "invivoPKfit",
#                             "Honda et al.")) %>%
#      ggplot(mapping = aes(
#        x = Fgutabs,
#        y = reorder(DTXSID, Fgutabs)
#      )) +
#      geom_point(aes(color = Source),
#                 shape = 24,
#                 position = position_dodge(0.7),
#                 size = 5/.pt, stroke = 2.5/.pt) +
#      scale_color_manual(values = c("black", "green4"),
#                         breaks = c("invivoPKfit", "Honda et al.")) +
#    labs(x = "Oral Bioavailability") +
#    guides(color = guide_legend(nrow = 2)) +
#      theme(panel.border = element_rect(color = "black", fill = NA, linewidth = 1.5),
#            panel.background = element_blank(),
#            panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#            strip.background = element_rect(fill = "white"),
#            strip.text = element_text(face = "bold", size = 12),
#            text = element_text(size = 10),
#            axis.ticks = element_blank(),
#            axis.line = element_blank(),
#            axis.text = element_text(face = "bold"),
#            axis.title.y = element_blank(),
#            legend.position = "bottom",
#            legend.key = element_blank(),
#            legend.title = element_text(face = "bold"),
#            legend.text = element_text())
#  
#  
#  plot_grid(sfig4A, sfig4B, align = "h", axis = "bt")
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "metaAnalysis_Comparisons_SuppFigure4.png"),
#         height = 3,
#         width = 5,
#         device = "png", dpi = 300)
#  

## ----do_fit-benchmarking, eval=FALSE------------------------------------------
#  
#  # Set to
#  single_core <- microbenchmark::microbenchmark(do_fit(my_pk, n_cores = 1), times = 3)
#  four_core <- microbenchmark::microbenchmark(do_fit(my_pk, n_cores = 4), times = 3)
#  # eight_core <- microbenchmark::microbenchmark(do_fit(my_pk, n_cores = 8), times = 3) # Only for four_DG
#  ten_core <- microbenchmark::microbenchmark(do_fit(my_pk, n_cores = 10), times = 3)
#  fourteen_core <- microbenchmark::microbenchmark(do_fit(my_pk, n_cores = 14), times = 3)
#  
#  single_core
#  four_core
#  # eight_core
#  ten_core
#  fourteen_core
#  
#  four_DG <- bind_rows(summary(single_core),
#                       summary(four_core),
#                       summary(eight_core),
#                       summary(ten_core),
#                       summary(fourteen_core)) # Done ~ 140s
#  
#  eight_DG <- bind_rows(summary(single_core),
#                        summary(four_core),
#                        summary(ten_core),
#                        summary(fourteen_core)) # Done
#  
#  sixteen_DG <- bind_rows(summary(single_core),
#                          summary(four_core),
#                          summary(ten_core),
#                          summary(fourteen_core)) # Done
#  
#  
#  my_pk %>% get_data() %>% dplyr::select(Chemical, Species) %>%
#    distinct() %>% nrow()
#  my_pk %>% get_data() %>% pull(Chemical) %>% unique() -> used_chemicals
#  
#  unused_cvt <- cvt %>%
#    dplyr::filter(!(chemicals_analyzed.dsstox_substance_id %in% used_chemicals))
#  
#  new_chemicals <- sample(unique(unused_cvt$chemicals_analyzed.dsstox_substance_id),
#                         size = 8)
#  
#  my_predata <- cvt %>%
#    dplyr::filter(chemicals_analyzed.dsstox_substance_id %in% union(used_chemicals,
#                                                                    new_chemicals))
#  my_predata %>%
#    dplyr::select(chemicals_analyzed.dsstox_substance_id, subjects.species_harmonized) %>%
#    distinct() %>% nrow()
#  
#  my_pk <- pk(data = my_predata) +
#    facet_data(vars(Chemical, Species)) +
#    settings_preprocess(keep_data_original = TRUE,
#                        suppress.messages = TRUE) +
#    settings_optimx(method = c("L-BFGS-B", "bobyqa")) +
#    scale_conc(dose_norm = TRUE, log10_trans = FALSE) +
#    # scale_time(new_units = "auto") +
#    # stat_model() +
#    stat_error_model(error_group = vars(Chemical, Species))
#  my_pk <- do_prefit(my_pk) # Then run again
#  
#  ##
#  ##
#  # After getting all of them
#  full_df <- bind_rows(
#    four_DG %>% mutate(data_group_N = 4),
#    eight_DG %>% mutate(data_group_N = 8),
#    sixteen_DG %>% mutate(data_group_N = 16)
#  )
#  
#  full_df <- full_df %>%
#    mutate(N_cores = as.numeric(str_extract(expr, pattern = "[:digit:]+")))
#  
#  full_long <- full_df %>%
#           dplyr::select(expr, N_cores, data_group_N, min, median, max) %>%
#           pivot_longer(cols = c(min, median, max)) %>%
#    dplyr::select(-name)
#  
#  df_long <- full_df %>%
#           dplyr::select(expr, N_cores, data_group_N, min, median, max) %>%
#           pivot_longer(cols = c(min, median, max)) %>%
#    dplyr::select(-name) %>% group_by(N_cores, data_group_N) %>%
#    summarize(avg_val = mean(value),
#              sd_val = sd(value))
#  
#  ggplot(full_long,
#         aes(x = N_cores,
#             y = value,
#             color = factor(data_group_N))) +
#  
#    geom_point() +
#    geom_line(data = df_long,
#              aes(x = N_cores,
#                  y = avg_val)) +
#    scale_x_continuous(breaks = c(0, 1, 4, 8, 10, 14)) +
#    labs(x = "Number of Cores",
#         y = "Runtime (seconds)",
#         color = "Data Groups",
#         title = "Parallelization diminishes runtime at scale") +
#    theme(panel.border = element_rect(color = "black", fill = NA, size = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          legend.key = element_rect(fill = "white"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank())
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "Parallelization_Benchmarking.png"),
#         width = 4.5,
#         height = 3.5,
#         units = "in")
#  

## ----sfig6-examples-of-fits, eval=FALSE---------------------------------------
#  pl <- plot(my_pk, use_scale_conc = TRUE, n_interp = 10)
#  names(pl) # Chemical Species observations observation_plot predicted predicted_plot final_plot
#  
#  s6_plA <- pl %>% filter(Chemical %in% "DTXSID3031860") %>%
#    pull(observation_plot) %>% .[[1]]
#  s6_plB_mouse <- pl %>% filter(Chemical %in% "DTXSID4020533",
#                                Species %in% "mouse") %>% pull(final_plot) %>% .[[1]]
#  s6_plB_rat <- pl %>% filter(Chemical %in% "DTXSID4020533",
#                                Species %in% "rat") %>% pull(final_plot) %>% .[[1]]
#  s6_plC <- pl %>% filter(Chemical %in% "DTXSID8021359") %>%
#    pull(final_plot) %>% .[[1]]
#  s6_plD <- pl %>% filter(Chemical %in% "DTXSID8025337") %>%
#    pull(final_plot) %>% .[[1]]
#  
#  # Set colors palettes for each
#  # panel A : Oranges
#  panelA_cols <- brewer.pal(8, "Oranges")[3:8]
#  # panel B : Greens
#  panelB_cols <- brewer.pal(9, "Greens")[2:9]
#  # panel C : Blue (only 2 values)
#  # panel D : Purple (6 values)
#  panelD_cols <- brewer.pal(9, "Purples")[4:9]
#  
#  s6_plA <- s6_plA +
#    labs(title = "perfluorodecanoic acid") +
#    scale_color_manual(values = panelA_cols, aesthetics = c("color", "fill")) +
#    theme(text = element_text(size = 20),
#          legend.position = "none",
#          strip.background = element_rect(fill = "white"))
#  
#  s6_plB_mouse <- s6_plB_mouse +
#    labs(title = "1,4-dioxane\nMouse") +
#    scale_color_manual(values = panelB_cols[c(5,8)],
#                       aesthetics = c("color", "fill")) +
#    theme(text = element_text(size = 20),
#          legend.position = "none",
#          strip.background = element_rect(fill = "white"))
#  
#  s6_plB_rat <- s6_plB_rat +
#    labs(title = "1,4-dioxane\nRat") +
#    scale_color_manual(values = panelB_cols[c(1, 2, 3, 4, 6,8)],
#                       aesthetics = c("color", "fill")) +
#    theme(text = element_text(size = 20),
#          legend.position = "none",
#          strip.background = element_rect(fill = "white"))
#  
#  s6_plC <- s6_plC +
#    labs(title = "tolbutamide") +
#    scale_color_manual(values = c("#6BAED6", "#08519C"),
#                       aesthetics = c("color", "fill")) +
#    theme(text = element_text(size = 20),
#          legend.position = "none",
#          strip.background = element_rect(fill = "white"))
#  
#  s6_plD <- s6_plD +
#    labs(title = "formamide") +
#    scale_color_manual(values = panelD_cols,
#                       aesthetics = c("color", "fill")) +
#    theme(text = element_text(size = 20),
#          legend.position = "none",
#          strip.background = element_rect(fill = "white"))
#  
#  # Put it all together
#  s6_plB <- plot_grid(s6_plB_mouse, s6_plB_rat,
#              align = "h", axis = "bt",
#             rel_widths = c(1.2,2))
#  
#  
#  s6_plCD <- plot_grid(s6_plC, s6_plD, labels = c("C", "D"), label_size = 24)
#  
#  
#  plot_grid(
#    s6_plA,
#    s6_plB,
#    s6_plCD,
#    align = "v",
#    ncol = 1,
#    rel_heights = c(1.25, 1, 1.25),
#    labels = c("A", "B", ""),
#    label_size = 24
#  )
#  
#  # Am making this 2X the size I need it to be
#  # so the points are a reasonable size when I scale it down
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ExampleFitsPlots_11.30.2023.png"),
#         width = 13,
#         height = 14,
#         units = "in")
#  

## ----more_analysis, eval=FALSE------------------------------------------------
#  
#  
#  my_pk$prefit$fit_check %>% filter(fit_decision == "abort") %>%
#    dplyr::select(model, Chemical) %>% distinct()
#  
#  all_my_data %>%
#    filter(Chemical == "DTXSID2021315")
#  
#  
#  # On average, how many time-points before tmax (empirical)?
#  my_nca %>% filter(param_name %in% "tmax") %>%
#    dplyr::select(Chemical, Species, Route, Media, tmax.nca = param_value) %>%
#    left_join(all_my_data) %>%
#    filter(Route %in% "oral", Time < tmax.nca) %>%
#    distinct(Chemical, Chemical_Name, Species, Route, Media, Detect, Time) %>%
#    group_by(Chemical, Chemical_Name, Species, Route, Media, Detect) %>%
#    count(name = "tp_before_tmax") %>%
#    ungroup() %>%
#    filter(Detect == TRUE) %>%
#    dplyr::select(!Detect) %>%
#    arrange(tp_before_tmax) %>%
#    count(tp_before_tmax > 1)
#  

## ----PredictionVariability_overtime, eval=FALSE-------------------------------
#  my_residuals %>%
#    filter(exclude == FALSE) %>%
#    inner_join(winmodel) %>%
#    inner_join(my_tkstats %>%
#                dplyr::select(Chemical, Species,
#                              Route, Media,
#                              tmax = tmax.tkstats) %>%
#                filter(!is.na(tmax))) %>%
#    group_by(Chemical,
#             Species,
#             Route,
#             Media,
#             Dose) %>%
#    mutate(
#           normTime = ifelse(
#             Route == "iv",
#             1 + Time/max(Time),
#             ifelse(
#               Time > tmax,
#               ((Time - tmax)/max(Time)) + 1,
#               0.5 + Time/(2*tmax)
#             )
#           )) %>%
#    distinct() %>%
#    filter(Detect %in% TRUE) -> my_residuals2
#  my_residuals2 %>%
#    # filter(Route == "oral") %>% View()
#    ggplot(aes(
#      x = normTime,
#      y = Residuals
#    )) +
#    geom_point(alpha = 0.2, size = 0.5) +
#    geom_point(data = filter(my_residuals2,
#                             Chemical %in% "DTXSID4020533",
#                             Species %in% "rat"),
#               color = "orange2", size = 0.5) +
#    geom_point(data = filter(my_residuals2,
#                             Chemical %in% "DTXSID8031865",
#                             Species %in% "rat"),
#               color = "magenta4", size = 0.5) +
#    geom_point(data = filter(my_residuals2,
#                             Chemical %in% "DTXSID8025337",
#                             Species %in% "rat"),
#               color = "green2", size = 0.5) +
#    geom_vline(xintercept = 1, color = "blue", linetype = "dashed") +
#    geom_vline(xintercept = 2, color = "green4", linetype = "dashed") +
#    facet_grid(cols = vars(Route),
#               # rows = vars(model),
#               scales = "free_x") +
#    labs(x = "ADME-Normalized Time",
#         y = "Winning Model Residuals") +
#    theme(aspect.ratio = 1,
#          panel.border = element_rect(color = "black", fill = NA, size = 1.5),
#          panel.background = element_blank(),
#          panel.grid.major = element_line(color = "grey90", linewidth = 0.5),
#          strip.background = element_rect(fill = "white"),
#          strip.text = element_text(face = "bold"),
#          axis.ticks = element_blank(),
#          axis.line = element_blank(),
#          axis.text.x = element_blank())
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"),
#                "ADME_NormalizedTime-WinModelResiduals_onlyDetects_Highlighted_2023-07-19.png"),
#         height = 4,
#         width = 6,
#         units = "in")

## ----function_connections, eval=FALSE-----------------------------------------
#  fw <- mvbutils::foodweb(where = asNamespace("invivoPKfit"),
#                          border = TRUE, cex = 0.6, lwd = 1.5)
#  fun_mat <- fw$funmat
#  
#  mvbutils::foodweb(where = asNamespace("invivoPKfit"),
#                    prune = "calc_auc",
#                    # descendants = FALSE,
#                    # ancestors = FALSE,
#                    border = TRUE, cex = 1, lwd = 1.5)
#  
#  # Predict dependents: rmse, residuals, rsq, calc_auc, fold_errors, plot
#  # Coef dependents: calc_auc, predict, get_tkstats, summary,log_Lik, coef_sd
#  
#  # list of all functions and methods
#  fm <- ls(asNamespace("invivoPKfit"))
#  fm <- fm[!grepl(".default", x = fm)]
#  
#  pdf(file = paste0(Sys.getenv("FIG_DIR"),
#                "NonDefaultFunction_Connections.pdf"),
#      height = 8, width = 8)
#  for (i in fm) {
#    mvbutils::foodweb(where = asNamespace("invivoPKfit"),
#                    prune = i,
#                    # descendants = FALSE,
#                    # ancestors = FALSE,
#                    border = TRUE, cex = 1, lwd = 1.5)
#  }
#  dev.off()
#  
#  
#  

## ----plotting_all_Fits, eval=FALSE--------------------------------------------
#  ### Plotting for all (2.5MB file)
#  pl <- plot(my_pk, n_interp = 12, use_scale_conc = TRUE)
#  pdf(file = paste0(Sys.getenv("FIG_DIR"),
#                "DoseNormalized_Joint_AllFits_Final_20240109.pdf"),
#      height = 6, width = 10)
#  for (i in 1:nrow(pl)) {
#    print(pl$final_plot[[i]])
#  }
#  dev.off()
#  
#  # From my new SQL pull
#  pl <- plot(my_pk, n_interp = 10, use_scale_conc = FALSE)
#  pdf(file = paste0(Sys.getenv("FIG_DIR"),
#                "Joint_AllFits_Final_20240109.pdf"),
#      height = 10, width = 10)
#  for (i in 1:nrow(pl)) {
#    print(pl$final_plot[[i]])
#  }
#  dev.off()
#  

## ----Explain-Heirarchical-Model, eval=FALSE-----------------------------------
#  # Note that the data will run one "Series" of time point at a time
#  my_1comp <- function(t, F_V, kelim, kabs, sd = 0) {
#    sd + (F_V * (kabs * (exp(-kelim * t) - exp(-kabs * t))) / (kabs - kelim))
#  }
#  
#  my_cdata <- data.frame(
#    Reference = rep(rep(c("X", "O"), each = 3), 6),
#    Time = rep(c(0, 2, 4, 6, 8, 12), each = 6),
#    Concentration = c(
#      4, 5, 6.5,
#      4.5, 5, 6,
#      8, 9, 9.5,
#      7.5, 8, 8.5,
#      3, 4.5, 6,
#      3.5, 4, 5,
#      2, 2.5, 4,
#      1, 1.5, 2.25,
#      0.4, 1, 2,
#      0.4, 0.8, 1,
#      0.2, 0.5, 1,
#      0.25, 0.4, 0.5
#    )
#  )
#  
#  
#  pl_pool <- ggplot() +
#    geom_point(data = my_cdata,
#               mapping = aes(
#                 x = Time,
#                 y = Concentration,
#                 color = Reference
#               ),
#               position = position_dodge(width = 0.4),
#               size = 2) +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8),
#      linewidth = 1) +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = 1),
#      linewidth = 0.5, linetype = "dashed") +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = -1),
#      linewidth = 0.5, linetype = "dashed") +
#    scale_y_continuous(breaks = scales::pretty_breaks(10)) +
#    scale_x_continuous(breaks = scales::pretty_breaks(13)) +
#    scale_color_manual(values = c("black", "black")) +
#    theme_classic() +
#    theme(axis.text = element_blank(),
#          axis.ticks = element_blank(),
#          axis.title = element_text(size = 12, face = "bold"),
#          axis.line = element_line(linewidth = 1, lineend = "square"),
#          legend.position = "none")
#  ggsave(paste0(Sys.getenv("FIG_DIR"), "PooledExampleFigure.png"),
#         units = "in",
#         height = 4,
#         width = 5,
#         device = "png",
#         dpi = 300)
#  
#  # Change shape(s) from circles
#  pl_joint <- ggplot() +
#    geom_point(data = my_cdata,
#               mapping = aes(
#                 x = Time,
#                 y = Concentration,
#                 color = Reference,
#                 shape = Reference
#               ),
#               position = position_dodge(width = 0.4),
#               size = 2) +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8),
#      linewidth = 1) +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = 1.3),
#      linewidth = 0.6, linetype = "dashed", color = "green4") +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = -1.3),
#      linewidth = 0.6, linetype = "dashed", color = "green4") +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = 0.7),
#      linewidth = 0.6, linetype = "dashed", color = "magenta3") +
#    stat_function(
#      fun = my_1comp,
#      args = list(F_V = 20, kelim = 0.6, kabs = 0.8, sd = -0.7),
#      linewidth = 0.6, linetype = "dashed", color = "magenta3") +
#    scale_y_continuous(breaks = scales::pretty_breaks(10)) +
#    scale_x_continuous(breaks = scales::pretty_breaks(13)) +
#    scale_color_manual(values = c("magenta3", "green4")) +
#    scale_shape_manual(values = c(15, 17)) +
#    theme_classic() +
#    theme(axis.text = element_blank(),
#          axis.ticks = element_blank(),
#          axis.title = element_text(size = 12, face = "bold"),
#          axis.line = element_line(linewidth = 1, lineend = "square"),
#          axis.title.y = element_blank(),
#          legend.position = "none")
#  
#  pl_joint
#  ggsave(paste0(Sys.getenv("FIG_DIR"), "JointExampleFigure.png"),
#         units = "in",
#         height = 4,
#         width = 5,
#         device = "png",
#         dpi = 300)
#  
#  
#  plot_grid(pl_pool, pl_joint,
#            align = "h", axis = "bt")
#  
#  ggsave(filename = paste0(Sys.getenv("FIG_DIR"),
#                           "Pooled_Joint_ExampleFigure.png"),
#         units = "in",
#         height = 3.4,
#         width = 6.5,
#         device = "png",
#         dpi = 300)
#  
#  ggplot(data.frame(point_size = seq(0.2, 3, by = 0.2)),
#         aes(x = as.factor(point_size), size = point_size)) +
#    geom_point(y = 0) +
#    scale_y_continuous(limits = c(-1, 1)) +
#    theme_bw() +
#    theme(legend.position = "none")
#  
#  ggsave(paste0(Sys.getenv("FIG_DIR"), "Point_Reference_3x5.png"),
#         units = "in",
#         height = 3,
#         width = 5,
#         device = "png",
#         dpi = 300)

## ----cvtdb-prep, eval=FALSE---------------------------------------------------
#  
#  my_cvt <- cvt
#  my_tkstats <- eval_tkstats(my_pk)
#  
#  my_cvt_unique <- my_cvt %>% dplyr::mutate(
#    preprocess_data_flags =
#      case_when(
#        (other_study_identifier %in% "S0916") ~ paste("Adjusted dose_level_original_units",
#                                                                "adjusted dose_level_normalized.",
#                                                                sep = " and "),
#        (other_study_identifier %in% "S0624") ~ paste("Adjusted dose_level_normalized."),
#        (document_id %in% c("65", "61", "46", "31")) ~ paste("Adjusted analyte_dtxsid",
#                                                             "adjusted analyte_name_original.",
#                                                             sep = " and "),
#        (other_study_identifier %in% c("S0976",
#                                       "S0361",
#                                       "S0328")) ~ paste("Adjusted loq and loq_units."),
#        (document_id %in% "38") ~ paste("Adjusted conc."),
#        (analyte_name_original %in% c("n-desmethyltamoxifen",
#                                      "methemoglobin")) ~ paste("Adjusted analyte_dtxsid."),
#        .default = NA_character_
#      )) %>%
#    group_by(analyte_dtxsid, species,
#      administration_route_normalized, conc_medium_normalized, preprocess_data_flags) %>%
#    summarize(document_ids = paste0(unique(document_id), collapse = ","))
#  
#  # Non-compartmental analysis
#  my_nca <- get_nca(my_pk) %>% dplyr::select(-param_units) %>%
#    mutate(param_name = paste0(param_name, ".nca")) %>%
#    group_by(Chemical, Species,
#             Route, Media, design) %>%
#    pivot_wider(names_from = param_name,
#                values_from = c(param_value, param_sd_z)) %>%
#    distinct() %>%
#    arrange(Chemical) %>%
#    rename_with(.fn = ~gsub("param_", "", .x)) %>%
#    rename_with(.fn = ~gsub("value_", "", .x)) %>%
#    rename(analyte_dtxsid = Chemical,
#           species = Species,
#           administration_route_normalized = Route,
#           conc_medium_normalized = Media)
#  
#  
#  my_cvt %>%
#    dplyr::select(analyte_dtxsid, species, radiolabeled) %>%
#    distinct() %>%
#    filter(analyte_dtxsid %in% (cvt %>% filter(radiolabeled) %>% pull(analyte_dtxsid)))
#  
#  # Writing to file
#  left_join(my_nca, my_cvt_unique) %>%
#    ungroup() %>%
#    filter(!is.infinite(AUC_infinity.nca), !is.infinite(AUMC_infinity.nca)) %>%
#    distinct() %>%
#    mutate(nca_id = row_number(),
#           .before = analyte_dtxsid) %>%
#    # View("NCA-CvTdb")
#    write_tsv("data-raw/NCA_CvTdb.tsv")
#  # Note that this will have more numbers because it still includes AUC_infinity == NA
#  
#  
#  
#  # TK stats
#  my_tkstats <- my_tkstats %>%
#    dplyr::select(analyte_dtxsid = Chemical, species = Species,
#                  administration_route_normalized = Route,
#                  conc_medium_normalized = Media,
#                  Reference,
#                  model, method,
#                  ends_with("tkstats")) %>%
#    group_by(across(everything())) %>%
#    ungroup(Reference) %>%
#    summarize(document_ids = paste0(unique(Reference), collapse = ",")) %>%
#    ungroup() %>%
#    distinct() %>%
#    arrange(analyte_dtxsid)
#  
#  prefit_df <- my_pk$prefit$fit_check %>% inner_join(get_winning_model(my_pk)) %>%
#    dplyr::select(analyte_dtxsid = Chemical, species = Species, model, method,
#                  fit_decision, fit_reason)
#  
#  left_join(my_tkstats, my_cvt_unique) %>%
#    left_join(prefit_df) %>%
#    ungroup() %>%
#    distinct() %>%
#    mutate(tkstats_id = row_number(), .before = analyte_dtxsid) %>%
#    # View("TKstats-CvTdb")
#    write_tsv("data-raw/tkstats_CvTdb.tsv")
#  

## ----information--------------------------------------------------------------
sessionInfo()


